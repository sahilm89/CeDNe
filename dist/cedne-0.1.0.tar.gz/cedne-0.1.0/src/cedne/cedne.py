import numpy as np
import random
import networkx as nx
import pandas as pd
from copy import copy, deepcopy
import matplotlib
import matplotlib.pyplot as plt
from warnings import warn
import pickle
import scipy.stats as ss
from scipy import signal
import random
import string

print("Blah")

##### TODO #####
'''
1. More inbuilt layers in the network.
    1.1 Integrate behavioral components.
2. Clean up the neurotransmitter table.
2. Add G-protein-Neuropeptide relations.
'''

# Superparameters
RANDOM_SEED = 42
F_SAMPLE = 5 # Hz


def generate_random_alphanumeric(length=8):
    """
    Generates a random alphanumeric string of a given length.
    
    Parameters:
    - length (int): The length of the alphanumeric string to generate. Default is 8.
    
    Returns:
    - str: A random alphanumeric string of the specified length.
    """
    characters = string.ascii_letters + string.digits
    return ''.join(random.choice(characters) for i in range(length))

class Worm:
    ''' This is a full organism class'''
    def __init__(self, name='') -> None:
        if not name:
            name = 'Worm-' + generate_random_alphanumeric() 
        self.name = name
        self.conditions = {}

class Behavior:
    ''' This is a behavior class for the organism'''
    def __init__(self, worm=None, condition="Neutral"):
        ## Class identification parameters
        if not worm == None:
            self.worm = worm
            self.worm.conditions.update({condition:self})
        else:
            self.worm = Worm("1")
            self.worm.conditions.update({condition:self})    
        
class NervousSystem(nx.MultiDiGraph):
    ''' This is a neural network class.'''
    def __init__(self, worm=None, condition="Neutral", currentIndex = 0, Input=[], Target=[], method='dynamic'):

        ## Networkx parameters
        nx.MultiDiGraph.__init__(self)

        ## Class identification parameters
        if not worm == None:
            self.worm = worm
            self.worm.conditions.update({condition:self})
        else:
            self.worm = Worm()
            self.worm.conditions.update({condition:self}) 

        ## Member list
        self.neuronDict = {}
        self.connectionDict = {}

        self.numGroups = 1
    
    def buildNervousSystem(self, neurons, chemSyns, elecSyns, position):
        ''' Makes neurons and synpases from pickleFile'''

        with open(neurons, 'rb') as ns, \
            open(chemSyns, 'rb') as chem, \
            open(elecSyns, 'rb') as elec, \
            open(position, 'rb') as pos:

                nodeDict = pickle.load(ns)
                chem_adj = pickle.load(chem)
                elec_adj = pickle.load(elec)
                posn = pickle.load(pos)
                nodelabels, l1_list, l2_list, l3_list = nodeDict.iloc[:,0].to_list(), nodeDict.iloc[:,1].to_list(), nodeDict.iloc[:,2].to_list(), nodeDict.iloc[:,3].to_list()
                self.makeNeurons(nodelabels, l1_list, l2_list, l3_list, posn)
                self.setupChemConnections(chem_adj)
                self.setupGapJunctions(elec_adj)
    
    def buildNetwork(self, neurons, adj, label):
        ''' Make a network with the neurons '''
        with open(neurons, 'rb') as ns:
            nodeDict = pickle.load(ns)
            nodelabels, l1_list, l2_list, l3_list = nodeDict.iloc[:,0].to_list(), nodeDict.iloc[:,1].to_list(), nodeDict.iloc[:,2].to_list(), nodeDict.iloc[:,3].to_list()
            self.makeNeurons(nodelabels, l1_list, l2_list, l3_list)
        self.setupConnections(adj, label)
    
    def updateNeuronDict(self):
        ''' Update the dictionary of neurons '''
        self.neuronDict = {}
        for n in self.nodes:
            self.neuronDict.update({n.name:n})
        
    def setupConnections(self, adj, edgeType):
        ''' Setting up edges here.'''
        for u, nbrs in adj.items():
            for v, d in nbrs.items():
                if (d['weight']>0):
                    k = self.add_edge(self.neuronDict[u], self.neuronDict[v], weight=d['weight'], color='purple', edgeType=edgeType)
                    self.connectionDict[(self.neuronDict[u], self.neuronDict[v], k)] = Connection(self.neuronDict[u], self.neuronDict[v],k, edgeType, weight=d['weight']) 

    def makeNeurons(self, nodeLabels, l1_list=[], l2_list=[], l3_list=[], position={}):
        ''' Makes a set of neurons from pickleFile'''
        for label,l1,l2,l3 in zip(nodeLabels, l1_list, l2_list, l3_list):
            if label in position:
                neuron = Neuron(label, self, l1, l2, l3, position[label])
            else:
                neuron = Neuron(label, self, l1, l2, l3) 
            self.neuronDict.update({label:neuron})

    def setupChemConnections(self, chem_adj):
        ## Can be extracted from setupConections, change later.
        edgeType = 'chem'
        ''' Setting the chemical synapses here.'''
        for u, nbrs in chem_adj.items():
            for v, d in nbrs.items():
                if (d['weight']>0):
                    k = self.add_edge(self.neuronDict[u], self.neuronDict[v], weight=d['weight'], color='orange', edgeType=edgeType)
                    self.connectionDict[(self.neuronDict[u], self.neuronDict[v], k)] = Connection(self.neuronDict[u], self.neuronDict[v],k, edgeType, weight=d['weight']) 
    #self.add_edges_from(e) # Add edge attributes here.

    def setupGapJunctions(self, elec_adj):
        ## Can be extracted from setupConections, change later.
        edgeType = 'gapjn'
        ''' Setting the gap junctions here'''
        for u, nbrs in elec_adj.items():
            for v, d in nbrs.items():
                if (d['weight']>0):
                    k = self.add_edge(self.neuronDict[u], self.neuronDict[v], weight=d['weight'], color='gray', edgeType=edgeType)
                    self.connectionDict[(self.neuronDict[u], self.neuronDict[v], k)] = Connection(self.neuronDict[u], self.neuronDict[v],k, edgeType, weight=d['weight'])
    def loadNeuronData(self, file, format='summary-xlsx'):
        ''' Standard formats to load data into the network'''
        pass

    def loadConnectionData(self, file, format='summary-xlsx'):
        ''' Standard formats to load data into the network'''
        pass

    def subNetwork(self, neuronList):
        ''' Set up a subgraph'''
        nlist = [self.neuronDict[n] for n in neuronList]
        tempNet = self.subgraph(nlist)
        subNet = deepcopy(tempNet)
        subNet.neuronDict = {n.name: n for n in subNet.nodes}
        return subNet
    
    def foldNetwork(self, filter):
        '''Fold the network based on a filter.'''
        allowed, exceptions = filter
        for npair in allowed:
            if not npair[0] in exceptions and not npair[1] in exceptions:
                self.contractNeurons(npair)

    def contractNeurons(self, neuronPair):
        '''Contract two neurons together. '''
        self = nx.contracted_nodes(self, self.neuronDict[neuronPair[0]],self.neuronDict[neuronPair[1]])
        self.updateNeuronDict()
    
    def neuronsHave(self, key):
        ''' Returns an arbitrary attribute for the neurons'''
        return nx.get_node_attributes(self, key)
    
    def connectionsHave(self, key):
        ''' Gets an arbitrary attribute for the connections'''
        return nx.get_edge_attributes(self, key)

    def __filter_node__(self, node):
        return node in self.__filteredNodes__

    def __filter_edge__(self, n1,n2,key):
        return (n1,n2,key) in self.__filteredEdges__
    
    def returnNetworkWhere(self, neuronsHave={}, connectionsHave={}, condition='AND'):
        ''' Filters the network based on neuron and connection attributes. Filters use key-value pairs. '''

        ## First filter the neurons
        totalList = []
        if len(neuronsHave):
            for (key, value) in neuronsHave.items():
                eachFilter = []
                for n, val in self.neuronsHave(key).items():
                    if val==value:
                        eachFilter.append(n)
                totalList.append(eachFilter)
            if condition=='AND':
                filteredList = []
                for n in self.neuronDict.keys():
                    if all(self.neuronDict[n] in sublist for sublist in totalList):
                        filteredList.append(self.neuronDict[n])

            elif condition=='OR':
                filteredList = []
                for n in self.neuronDict.keys():
                    if any(self.neuronDict[n] in sublist for sublist in totalList):
                        filteredList.append(self.neuronDict[n])
        else:
            filteredList = list(self.neuronDict.values())
        
        self.__filteredNodes__ = filteredList

        ## Then filter the connections
        totalList = []
        if len(connectionsHave):
            for (key, value) in connectionsHave.items():
                eachFilter = []
                for e, val in self.connectionsHave(key).items():
                    if val==value:
                        eachFilter.append(e)
                totalList.append(eachFilter)
            #print(totalList)
            if condition=='AND':
                filteredList = []
                for e in self.connectionDict.keys():
                    if all(e in sublist for sublist in totalList):
                        filteredList.append(e)

            elif condition=='OR':
                filteredList = []
                for e in self.connectionDict.keys():
                    if any(e in sublist for sublist in totalList):
                        filteredList.append(e)
        else:
            filteredList = list(self.connectionDict.keys())
        
        self.__filteredEdges__ = filteredList
        #print(self.__filteredEdges__)

        return nx.subgraph_view(self, filter_node=self.__filter_node__, filter_edge=self.__filter_edge__)
class NeuronGroup:
    ''' This is a subgroup of the whole neuronal network'''
    def __init__(self, groupname, members) -> None:
        self.groupName = groupname
        self.members = members

class Neuron:
    ''' Models a biological neuron'''
    def __init__(self, name, nn, l1='', l2='', l3='', position={}, preSynapse= [], postSynapse= {}, neuronType='HH', Vm=-65e-3, Rm=1e8, Cm=100e-12, V_th=-55e-3, Vrest=-65e-3, refrac_abs=1e-3):
        
        ## Class identification parameters
        self.name = name     
        self.groupId = 0 # Put groups here later.
        self._data = {}
        self.trial = {}
        self.features = {0: 'Ca_max', 1: 'Ca_area', 2: 'Ca_avg',
                    3: 'Ca_time_to_peak', 4: 'Ca_area_to_peak',
                    5: 'Ca_min', 6: 'Ca_onset', 7:'positive_area',8: 'positive_time'}
        self.type = l1
        self.category = l2
        self.modality = l3
        self.position = position

        self.presynapse = preSynapse
        self.postSynapse = postSynapse

        self.inConnections = {}
        self.outConnections = {}

        self.nn = nn
        self.nn.add_node(self, type=self.type, category=self.category, modality=self.modality)

    def setPreSynapse(self, preSynapse=[]):
        self.preSynapse = preSynapse

    def setPostSynapse(self, postSynapse={}):
        self.postSynapse = postSynapse  # {Receptor: ['Ligand_0', 'Ligand_1', ...]}
    
    def addTrial(self, trialNum=0):
        self.trial[trialNum] = Trial(self, trialNum)
        return self.trial[trialNum]
    
    def getAllConnections(self):
        return [e for e in self.nn.edges if e[0] == self or e[1] == self]

    def outgoing(self):
        return self.outConnections

    def incoming(self):
        return self.inConnections
       
    def setProperty(self, key, val):
        ''' Sets an arbitrary attribute for the class'''
        setattr(self, key, val)
        nx.set_node_attributes(self.nn, {self:{key:val}})

class Trial:
    """ This is the trial class for different trials on the same wo Write a utir, neuron, etc"""
    def __init__(self, parent, trialNum):
        self.parent = parent
        self.i = trialNum

    @property
    def recording(self):
        return self._data

    @recording.setter
    def recording(self, signal):
        ''' Set timecourse data'''
        # Hard coded here, need to figure out by talking to Jingting.
        if len(signal) == 451:
            self._data = signal.astype(np.float64)
            self.discard = []
        elif len(signal) == 601:
            self.discard = 30*F_SAMPLE #Points to be discarded due to bleaching 
            self._data = signal[30*F_SAMPLE:].astype(np.float64)
        else:
            raise ValueError("Wierd size of timecourse")

        self.OP_pre = StimResponse(self, 'OP_pre', self._data[:len(self._data)//3])
        self.PA = StimResponse(self, 'PA', self._data[len(self._data)//3:2*(len(self._data)//3)])
        self.OP_post = StimResponse(self, 'OP_post', self._data[2*(len(self._data)//3):])

class StimResponse:
    ''' This is the stimulus and response class, for different trials on the same worm, neuron, etc'''
    def __init__(self, trial, stimulus, response) -> None:
        self.stim = stimulus
        self.response = response
        self.feature = {}
        self.neuron = trial.parent
        self.F_sample = F_SAMPLE # frames per sec
        self.samplingTime = 1./self.F_sample
        self.baseline = self.response[:10] 

        for featureIndex in range(len(self.neuron.features)):
            self.feature.update({featureIndex: self.extractFeature(featureIndex)})

    def extractFeature(self, feature):

        if feature == 0:
            return self._findMaximum()
        elif feature == 1:
            return self._areaUnderTheCurve()
        elif feature == 2:
            return self._findMean()
        elif feature == 3:
            return self._findTimeToPeak()
        elif feature == 4:
            return self._areaUnderTheCurveToPeak()
        elif feature == 5:
            return self._findMinimum()
        elif feature == 6:
            return self._findOnsetTime()
        elif feature == 7:
            return self._findPositiveArea()[0]
        elif feature == 8:
            return self._findPositiveArea()[1]
        elif feature == 9:
            return self._absoluteAreaUnderTheCurve()
    
    # Features
    def _findMaximum(self):
        '''Finds the maximum of the vector in a given interest'''
        return np.max(self.response)

    def _findMinimum(self):
        '''Finds the maximum of the vector in a given interest'''
        return np.min(self.response)

    def _findTimeToPeak(self):
        '''Finds the time to maximum of the vector in a given interest'''
        maxIndex = np.argmax(self.response)
        timeToPeak = (maxIndex)*self.samplingTime
        return timeToPeak

    def _findMean(self):
        '''Finds the mean of the vector in a given interest'''
        return np.average(self.response)

    def _areaUnderTheCurve(self, binSize=5):
        '''Finds the area under the curve of the vector in the given window.
           This will subtract negative area from the total area.'''
        undersampling = self.response[::binSize]
        auc = np.trapz(undersampling, dx=self.samplingTime*binSize)  # in V.s
        return auc
    
    def _absoluteAreaUnderTheCurve(self, binSize=5):
        '''Finds the area under the curve of the vector in the given window.
           This will subtract negative area from the total area.'''
        undersampling = np.abs(self.response[::binSize])
        auc = np.trapz(undersampling, dx=self.samplingTime*binSize)  # in V.s
        return auc

    def _areaUnderTheCurveToPeak(self, binSize=10):
        '''Finds the area under the curve of the vector in the given window'''
        undersampling = self.response[::binSize]
        maxIndex = np.argmax(undersampling)
        windowToPeak = undersampling[:maxIndex+1]
        auctp = np.trapz(windowToPeak, dx=self.samplingTime*binSize)  # in V.s
        return auctp

    def _findOnsetTime(self, step=2, slide = 1, maxOnset = 50., initpValTolerance=0.5):
        ''' Find the onset of the curve using a 2 sample KS test 
	maxOnset, step and slide are in ms'''

        window_size = int(step*self.F_sample)
        step_size = int(slide*self.F_sample)
        index_right = window_size
        for index_left in range(0, len(self.response)+1-window_size, step_size):
            stat, pVal = ss.ks_2samp(self.baseline, self.response[index_left:index_right])
            index_right += step_size
            if pVal < initpValTolerance:
                # print index_left, pVal, stat#, self.self.response_raw[index_left:index_right]
                break
        return float(index_left)/self.F_sample

    def _findPositiveArea(self, binSize=10):
        '''Finds the area under the curve of the vector in the given window'''
        undersampling = self.response[::binSize]
        undersampling = undersampling[np.where(undersampling>0.)]
        auc_pos = np.trapz(undersampling,  dx=self.samplingTime*binSize)  # in V.s
        positiveTime = self.samplingTime*len(undersampling)
        return auc_pos, positiveTime 

    #def _flagNoise(self, pValTolerance=0.01):
    #    ''' This function asseses if the distributions of the baseline and interest are different or not '''
    #    m, pVal = ss.ks_2samp(self.baselineWindow, self.self.response)
    #    if pVal < pValTolerance:
    #        return 0
    #    else:
    #        print "No response measured in trial {}".format(self.index)
    #        return 1  # Flagged as noisy

    # Transformations
    def _linearTransform(self, value, minValue, maxValue):
        return (value - minValue)/(maxValue - minValue)

    def _normalizeToBaseline(self, baselineWindow):
        '''normalizes the vector to an average baseline'''
        baseline = np.average(baselineWindow)
        response_new = self.response - baseline  # Subtracting baseline from whole array
        return response_new, baseline

    def _filter(self, filter='', cutoff=2000., order=4, trace=[]):
        ''' Filter the time series vector '''
        if not len(trace):
            trace = self.response

        if filter == 'bessel':
            cutoff_to_niquist_ratio = 2*cutoff/(self.F_sample) # F_sample/2 is Niquist, cutoff is the low pass cutoff.
            b, a = signal.bessel(order, cutoff_to_niquist_ratio, analog=False)
            trace =  signal.filtfilt(b, a, trace)
        return trace
            
    def _smoothen(self, smootheningTime):
        '''normalizes the vector to an average baseline'''
        smootheningWindow = smootheningTime*1e-3*self.F_sample
        window = np.ones(int(smootheningWindow)) / float(smootheningWindow)
        self.response = np.convolve(self.response, window, 'same')  # Convolving with a rectangle
        return self.response

class Connection:
    def __init__(self, neuron1, neuron2, uid =0, edgeType='chem', weight=1): #, rp=1, preConductionDelay= 0., postConductionDelay = 0., rev=0., tau_decay = 10e-3):
        ''' Make sure the id doesn't already exist, so that a unique identifier can be added to the synapse id.
        This is because 2 neurons can have more than one synapse. Putting 0 for now. '''
        self.__uid__ = uid
        self.__id__ = (neuron1, neuron2, self.__uid__)
        self.edgeType = edgeType
        self.w = weight  
        self.preNeuron = neuron1
        self.postNeuron = neuron2
        
        assert self.preNeuron.nn == self.postNeuron.nn
        self.nn = self.postNeuron.nn
        
        if self.__id__ not in self.preNeuron.outConnections.keys():
            self.preNeuron.outConnections[self.__id__] = self
        if self.__id__ not in self.postNeuron.inConnections.keys():
            self.postNeuron.inConnections[self.__id__] = self
        
    def updateWeight(self, w, delta=False):
        ''' Sets the connection weight '''
        if not delta:
            self.w = w
        else:
            self.w += w
        nx.set_edge_attributes(self.nn, {self.__id__:{'weight':self.w}})
    
    def setProperty(self, key, val):
        ''' Sets an arbitrary attribute for the class'''
        setattr(self, key, val)
        nx.set_edge_attributes(self.nn.graph, {self.__id__:{key:val}})
